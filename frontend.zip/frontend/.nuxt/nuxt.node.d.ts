/// <reference types="@nuxt/eslint" />
/// <reference types="@pinia/nuxt" />
/// <reference types="@nuxt/telemetry" />
/// <reference types="@nuxt/devtools" />
/// <reference types="@nuxt/ui" />
/// <reference path="types/nitro-layouts.d.ts" />
/// <reference path="types/modules.d.ts" />
/// <reference path="types/runtime-config.d.ts" />
/// <reference path="types/shared-app.config.d.ts" />
/// <reference types="nuxt" />
/// <reference path="../node_modules/@nuxt/vite-builder/dist/index.d.mts" />
/// <reference path="../node_modules/@nuxt/nitro-server/dist/augments.d.mts" />
/// <reference path="eslint-typegen.d.ts" />
/// <reference path="types/nitro-middleware.d.ts" />
/// <reference path="schema/nuxt.schema.d.ts" />

export {}
